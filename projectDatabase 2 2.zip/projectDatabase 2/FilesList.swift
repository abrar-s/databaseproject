//
//  FilesList.swift
//  projectDatabase
//
//  Created by MacBook on 10/18/20.
//  Copyright © 2020 abrarabrarabrar. All rights reserved.
//

import SwiftUI

struct FilesList: View {
    
    @State var files: [MedicalFile] = []
    var body: some View {
        List(files, id: \.self){   file in
            VStack(alignment: .leading){
                Text(file.Pname)
                Text(file.phone)
                Text(file.civilID)
                 Text(file.BloodType)
                                           }.padding()
        }.onAppear() {
            let U = UserDefaults.standard
            if let savedFiles = U.value(forKey: "files") as?
                [[String: String]]
            {
                for a in savedFiles{
                let file = MedicalFile.init(value: a)
                    self.files.append(file)
                }
            }
            
        }
    }
}

struct AccountList_Previews: PreviewProvider {
    static var previews: some View {
        FilesList()
    }
}
