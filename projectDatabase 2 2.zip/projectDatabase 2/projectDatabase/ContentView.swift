//
//  ContentView.swift
//  projectDatabase
//
//  Created by MacBook on 10/18/20.
//  Copyright © 2020 abrarabrarabrar. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        VStack{
                   NavigationView{
                
                NavigationLink(destination: Infofile()) {
                    Text("medical files").font(.largeTitle).fontWeight(.heavy).foregroundColor(Color.red).padding(.bottom)
                                }
            
           
            }
             Image("medical-files")
                          
                                   }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
