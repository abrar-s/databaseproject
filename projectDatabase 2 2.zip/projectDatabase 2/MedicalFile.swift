//
//  MedicalFile.swift
//  projectDatabase
//
//  Created by MacBook on 10/18/20.
//  Copyright © 2020 abrarabrarabrar. All rights reserved.
//

import Foundation

struct MedicalFile: Hashable, Codable {
    var Pname: String
    var civilID: String
    var phone: String
     var BloodType: String
    
    func encode() -> [String: Any] {
        ["Pname": Pname, "civilID": civilID, "phone": phone, "BloodType":BloodType]
    }
    
}

extension MedicalFile{
    init(value: [String: Any])
    {
         var Pname = value["Pname"] as! String
        var civilID = value["civilID"] as! String
    var phone = value["phone"] as! String
        var BloodType = value["BloodType"] as! String
        
        self.Pname = Pname
        self.civilID = civilID
        self.phone = phone
        self.BloodType=BloodType
    }
    
}
