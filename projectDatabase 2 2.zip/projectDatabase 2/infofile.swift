//
//  Infofile.swift
//  projectDatabase
//
//  Created by MacBook on 10/18/20.
//  Copyright © 2020 abrarabrarabrar. All rights reserved.
//

import SwiftUI

struct Infofile: View {
    @State var file = MedicalFile(Pname: "", civilID: "", phone: "", BloodType: "")
    
    @State var transit = false
    var body: some View {
        
        
        
        VStack{
               Form{
                   Section{
                    Text("Create New File")
                        .font(.title)
                        .fontWeight(.semibold)
                        .foregroundColor(Color.black)
                                                             TextField("Patient Name", text: $file.Pname)
                    TextField("Civil ID", text: $file.civilID)
                    TextField("Phone number", text: $file.phone)
                    TextField("Blood Type", text: $file.BloodType)
                                      Button(action: {
                       
                                        self.saveFileInfo(file: self.file)
          
                       
                   }   )  {
           
                       Text("Save")
                   }
                   }
               
                   
                   Section{
                   Button(action: {
                       self.transit = true
                   }) {
               Text("Show all patient files ")
                   }
                   }
               }
        
        }.onAppear {
                let U = UserDefaults.standard
                print(U.value(forKey: "files"))
                
            }
        
            .sheet(isPresented: $transit) {
                FilesList()
            }
                
        
        
        
        
        
        
        
        
        
    }
    
    func saveFileInfo(file:MedicalFile ){
        let U = UserDefaults.standard
        
        if let oldData = U.value(forKey: "files")
        
        {
            
            if let oldData = oldData as? [[String: Any]]{
                var dataTosave = oldData
                dataTosave.append(file.encode())
            U.set(dataTosave, forKey: "files")
            }
        }
        else{
            
            print(" old data is not there")
            let dataTosave = [file.encode()]
            U.set(dataTosave, forKey: "files")
        }
        
    }
    
    
}

struct Infofile_Previews: PreviewProvider {
    static var previews: some View {
        Infofile()
    }
}
